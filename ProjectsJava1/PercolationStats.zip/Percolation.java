import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.WeightedQuickUnionUF;

// Models an N-by-N percolation system.
public class Percolation {
    public boolean grid[][];

    // Create an N-by-N grid, with all sites blocked.
    public Percolation(int N) {
        this.grid = new boolean [N][N];
        for (int i = 0; i > N; i++ ) {
            for (int j = 0; j < N; j++) {
                this.grid[i][j] = false;
            }
        }
    }
    // Open site (i, j) if it is not open already.
    public void open(int i, int j) {
        this.grid[i][j] = true;
    }
    // Is site (i, j) open?
    public boolean isOpen(int i, int j) {
        return this.grid[i][j];
    }
    // Is site (i, j) full?
    public boolean isFull(int i, int j) {
        if (i >= this.grid.length ||
                i < 0 ||
                j >= this.grid[0].length ||
                j < 0 ||
                !this.isOpen(i, j)) {
            return false;
        } else if (i == 0) {
            return true;
        } else {
            return this.isFull(i - 1, j) ||
                   this.isFull(i + 1, j) ||
                   this.isFull(i, j - 1) ||
                   this.isFull(i , j + 1);
        }
    }
    // Number of open sites.
    public int numberOfOpenSites() {
        int counterOpenSites = 0;
        for (int row = 0 ; row < this.grid.length; row++) {
            for (int col = 0; col < this.grid[row].length; col++) {
                if (this.isOpen(row, col)) {
                    counterOpenSites++;
                }
            }
        }
        return counterOpenSites;
    }
    //Does the system percolate?
    public boolean percolates() {
        // this.grid[this.grid.length -1]
        int lastRowIndex = this.grid.length - 1;
        for (int i = 0; i < this.grid[lastRowIndex].length; i++) {
            if (this.isOpen(lastRowIndex, i)) {
                if (this.isFull(lastRowIndex, i)) {
                    return true;
                }
            }
        }
         return false;
    }


// An integer ID (1...N) for site (i, j).
//     private int encode(int i, int j) {
//         int encode = 0;
//         encode(size * i + j + 1);
//     }

// Test client. [DO NOT EDIT]
    public static void main(String[] args) {
        String filename = args[0];
        In in = new In(filename);
        int N = in.readInt();
        Percolation perc = new Percolation(N);
        while (!in.isEmpty()) {
            int i = in.readInt();
            int j = in.readInt();
            perc.open(i, j);
        }
        StdOut.println(perc.numberOfOpenSites() + " open sites");
        if (perc.percolates()) {
            StdOut.println("percolates");
        } else {
            StdOut.println("does not percolate");
        }

        // Check if site (i, j) optionally specified on the command line
        // is full.
        if (args.length == 3) {
            int i = Integer.parseInt(args[1]);
            int j = Integer.parseInt(args[2]);
            StdOut.println(perc.isFull(i, j));
        }
    }
}